/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   aff_first_param.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mcampilh <mcampilh@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/07 18:56:26 by mcampilh          #+#    #+#             */
/*   Updated: 2024/03/07 19:06:07 by mcampilh         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	main(int args, char *str[])
{
	int	i;
	
	i = 0;
	if (args < 2)
	{
		write (1, "\n", 1);
		return (0);
	}
	else
	{
		while (str[1][i])
		{
			write (1, &str[1][i++], 1);
		}
		write (1, "\n", 1);
	}
	return (0);
}
